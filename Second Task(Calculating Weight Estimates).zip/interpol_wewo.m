function [y]  = interpol_wewo(ip)
% ip= weight in N (range from 975*9.81-3062kg)
% y = empty weight ratio interpolated

% data of utility aircraft taken in the range 1000-2000Kgs
% mass empty mass 	Aircraft
% 1089 624          Beechcraft Musketeer
% 1198 795          DA40
% 1633 1134         cessna 400
% 1528 1080 		Mooney M20
% 975  544          Piper PA-28 Cherokee
% 1656 1142 		Beechcraft Bonanza
% 1512 994          Bellanca Viking
% 1090 680          Grumman American AA-5
% 1406 894          cesna 182
% 1181 783          Van's Aircraft RV-10
% few values ommited to avoid poor interpolation

% massx9.81=weight
z=[ 1089	624
    1198	795
    975     544
    1656	1142
    1406	894
    2313	1431
    3062	1980
    2864	1939];

% empty weight ratio 
wewo=z(:,2)./z(:,1);
% Wo
wo=z(:,1);

% plot(wo,wewo,'o');
% hold on
% wo_ip=linspace(min(wo),max(wo),100);
% wewo_ip=spline(wo,wewo,wo_ip);
% plot(wo_ip,wewo_ip);

% cubic splines used (higher order polynomials will have large oscillations in the fit)
y=ppval(spline(wo,wewo),ip);
%{
xx=975:5:3062;
yy=spline(wo,wewo,xx);
plot(wo,wewo,'o',xx,yy);
%}
end